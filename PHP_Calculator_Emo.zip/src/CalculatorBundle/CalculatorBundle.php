<?php

namespace CalculatorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CalculatorBundle extends Bundle
{
}
